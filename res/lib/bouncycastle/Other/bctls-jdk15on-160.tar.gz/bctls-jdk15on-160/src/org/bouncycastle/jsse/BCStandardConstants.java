package org.bouncycastle.jsse;

import org.bouncycastle.tls.NameType;

public final class BCStandardConstants
{
    public static final int SNI_HOST_NAME = NameType.host_name;
}
