package org.bouncycastle.jsse.provider;

interface ProvTlsPeer
{
    boolean isHandshakeComplete();
}
