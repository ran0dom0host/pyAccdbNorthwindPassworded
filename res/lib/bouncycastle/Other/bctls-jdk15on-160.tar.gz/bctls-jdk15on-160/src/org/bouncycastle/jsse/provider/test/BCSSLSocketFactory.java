package org.bouncycastle.jsse.provider.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

import org.bouncycastle.jsse.provider.BouncyCastleJsseProvider;

public class BCSSLSocketFactory
    extends SSLSocketFactory
{
    private static final String DEFAULT_PASSWORD = "changeit";

    private SSLSocketFactory socketFactory;

    public BCSSLSocketFactory()
        throws IOException, KeyStoreException,
        NoSuchProviderException, NoSuchAlgorithmException, CertificateException,
        UnrecoverableKeyException, KeyManagementException
    {

        String provider =
            System.getProperty("javax.net.ssl.keyStoreProvider");
        String keystoreType =
            System.getProperty("javax.net.ssl.keyStoreType", KeyStore.getDefaultType());

        KeyStore keystore = null;
        if (provider != null)
        {
            keystore = KeyStore.getInstance(keystoreType, provider);
        }
        else
        {
            keystore = KeyStore.getInstance(keystoreType);
        }

        String keystorePath =
            System.getProperty("javax.net.ssl.trustStore",
                System.getProperty("java.home") 
                    + "/lib/security/cacerts".replace('/',  File.separatorChar));
        String keystorePassword =
            System.getProperty("javax.net.ssl.trustStorePassword", DEFAULT_PASSWORD);

        InputStream kIn = null;
        try
        {
            kIn = new FileInputStream(keystorePath);
            keystore.load(kIn, keystorePassword.toCharArray());
        }
        finally
        {
            if (kIn != null)
            {
                kIn.close();
            }
        }

        KeyManagerFactory kmf =
            KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(keystore, keystorePassword.toCharArray());

        SSLContext sslContext = SSLContext.getInstance("TLS", new
            BouncyCastleJsseProvider());

        TrustManagerFactory trustMgrFact =
            TrustManagerFactory.getInstance("PKIX", "BCJSSE");
        trustMgrFact.init(keystore);

        sslContext.init(null, trustMgrFact.getTrustManagers(), null);

        socketFactory = sslContext.getSocketFactory();
    }

    @Override
    public Socket createSocket(Socket s, String host, int port, boolean autoClose)
        throws IOException
    {
        return socketFactory.createSocket(s, host, port, autoClose);
    }

    @Override
    public String[] getDefaultCipherSuites()
    {
        return socketFactory.getDefaultCipherSuites();
    }

    @Override
    public String[] getSupportedCipherSuites()
    {
        return socketFactory.getSupportedCipherSuites();
    }

    @Override
    public Socket createSocket()
        throws
        IOException, UnknownHostException
    {
        return socketFactory.createSocket();
    }

    @Override
    public Socket createSocket(String host, int port)
        throws
        IOException, UnknownHostException
    {
        return socketFactory.createSocket(host, port);
    }

    @Override
    public Socket createSocket(InetAddress host, int port)
        throws
        IOException
    {
        return socketFactory.createSocket(host, port);
    }

    @Override
    public Socket createSocket(String host, int port, InetAddress localHost, int localPort)
        throws IOException, UnknownHostException
    {
        return socketFactory.createSocket(host, port, localHost, localPort);
    }

    @Override
    public Socket createSocket(InetAddress address, int port, InetAddress localAddress, int localPort)
        throws IOException
    {
        return socketFactory.createSocket(address, port, localAddress, localPort);
    }
}
